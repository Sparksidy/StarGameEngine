#ifndef BODY_H
#define BODY_H
#include "Component.h"

class Body : public Component{
public:
	Body();
	~Body();

	void Update();
	void Serialize(FILE **fp);
	void Integrate(float deltaTime, float gravity);

public:
	float Xpos, Ypos;
	float prevXpos, prevYpos;
	float VelX, VelY;
	float AccX, AccY;
	float mTotalForceX, mTotalForceY;
	float mMass, mInverseMass;


};


#endif