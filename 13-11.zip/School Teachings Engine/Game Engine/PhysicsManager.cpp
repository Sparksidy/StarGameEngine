#include "PhysicsManager.h"
#include "GameObjectManager.h"
#include "Body.h"

PhysicsManager::PhysicsManager()
{


}


PhysicsManager::~PhysicsManager()
{


}
void PhysicsManager::Integrate(float deltaTime, float gravity, GameObjectManager* pTrGameObjManager)
{

	for (GameObjectInstance* pObj : pTrGameObjManager->mGameObjects)
	{
		Body* pBody = (Body*)pObj->GetComponent(COMPONENT_BODY);
		if (NULL != pBody)
		{
			pBody->Integrate(deltaTime * 0.001, gravity);
		}
	}

}
