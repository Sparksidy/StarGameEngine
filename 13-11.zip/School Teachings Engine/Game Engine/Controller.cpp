#include "Controller.h"
#include "GameObjectInstance.h"

Controller::Controller(){
	mpIM = new InputManager();
	
}

void Controller::Update(){

	if (mpIM != NULL)
	{
		if (mpOwner)
		{
			//Updating the keyboard state
			mpIM->Update();

			Transform* pTr = (Transform *)mpOwner->GetComponent(COMPONENT_TRANSFORM);

			if (pTr)
			{
				//Checking for keypress events

				if (mpIM->IsPressed(SDL_SCANCODE_UP)){
					pTr->mPosition.y -= speed * 0.5f;
				
				}
				else if (mpIM->IsPressed(SDL_SCANCODE_DOWN)){
					pTr->mPosition.y += speed * 0.5f;

				}
				else if (mpIM->IsPressed(SDL_SCANCODE_LEFT)){
					pTr->mPosition.x -= speed * 0.5f;
				}
				else if (mpIM->IsPressed(SDL_SCANCODE_RIGHT)){
					pTr->mPosition.x += speed * 0.5f;

				}


			}


		}
		
		


	}
	

		

}


Controller::~Controller(){

}

void Controller::Serialize(FILE** fpp)
{
	fscanf(*fpp, "%f ", &speed);
	
}