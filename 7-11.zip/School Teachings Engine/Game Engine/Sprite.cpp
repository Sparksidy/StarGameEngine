#include "Sprite.h"

Sprite::Sprite()
{

	mpSprite = NULL;
	mpOwner = NULL;

}
Sprite::~Sprite(){


}

void Sprite::AddSprite(SDL_Surface* surface){
	mpSprite = surface;

}

void Sprite:: DrawAtTransform(SDL_Surface* Surf_Dest, SDL_Surface* Surf_Src, int X, int Y){
	if (Surf_Dest == NULL || Surf_Src == NULL){
		return;
	}

	SDL_Rect Dest_R;
	Dest_R.x = X;
	Dest_R.y = Y;

	SDL_BlitSurface(Surf_Src, NULL, Surf_Dest, &Dest_R);

}

 

