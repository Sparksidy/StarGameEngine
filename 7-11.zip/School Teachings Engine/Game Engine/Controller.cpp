#include "Controller.h"
#include "GameObjectInstance.h"

Controller::Controller(GameObjectInstance* mpOwner_){
	mpIM = new InputManager();
	mpOwner = mpOwner_;
	speed = 10;
	
}

void Controller::DoMovement(){

	
	
	if (mpIM != NULL)
	{

		//Updating the keyboard state
		mpIM->Update();

		//Checking for keypress events
		if (mpIM->IsPressed(SDL_SCANCODE_UP)){
			
			mpOwner->mpTransformComponent->mPosition.y -= speed;

		}
		else if (mpIM->IsPressed(SDL_SCANCODE_DOWN)){
			mpOwner->mpTransformComponent->mPosition.y += speed;

		}
		else if (mpIM->IsPressed(SDL_SCANCODE_LEFT)){
			mpOwner->mpTransformComponent->mPosition.x -= speed;

		}
		else if (mpIM->IsPressed(SDL_SCANCODE_RIGHT)){
			mpOwner->mpTransformComponent->mPosition.x += speed;

		}


	}
	

		

}


Controller::~Controller(){

}