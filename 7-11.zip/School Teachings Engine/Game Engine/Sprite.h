#ifndef SPRITE_H
#define SPRITE_H

#include <SDL.h>
#include "Component.h"

class GameObjectInstance;

class Sprite:public Component{

public:
	Sprite();
	
	~Sprite();

	void AddSprite(SDL_Surface* surface);
	
	void DrawAtTransform(SDL_Surface* Surf_Dest, SDL_Surface* Surf_Src, int X, int Y);
	
	virtual void Update(){}

	//virtual void Serialize(){}
	

public:
	SDL_Surface* mpSprite;

	GameObjectInstance* mpOwner;

};



#endif