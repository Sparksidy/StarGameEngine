/*
	Abstract class for the components
	GameObjects are composed of components
*/
#ifndef COMPONENT_H
#define COMPONENT_H

#include <unordered_map>


class Component{

public:
	
	virtual void Update()=0;
	//virtual void Serialize();
	virtual ~Component(){}


public:
	



};

#endif