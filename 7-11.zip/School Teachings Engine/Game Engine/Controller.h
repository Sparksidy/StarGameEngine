/*
Controlling the movement of any GameObject

*/



#ifndef CONTROLLER_H
#define CONTROLLER_H

//#include "Component.h"

//#include "GameObjectInstance.h"
#include "Component.h"
#include "InputManager.h"

class GameObjectInstance;


class Controller: public Component{

public:
	Controller(GameObjectInstance* mpOwner_);
	void DoMovement();
	virtual void Update(){}
	//virtual void Serialize(){}

	~Controller();
public:
	InputManager* mpIM;
	GameObjectInstance* mpOwner;
	float speed;

};


#endif