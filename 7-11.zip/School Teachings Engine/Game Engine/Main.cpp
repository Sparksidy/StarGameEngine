#include <SDL.h>
#include "stdio.h"
#include "InputManager.h"
#include "FrameRateController.h"
#include "windows.h"
#include "ResourceManager.h"
#include "Sprite.h"
#include "Transform.h"
#include "GameObjectInstance.h"

//For File import
#include "stdio.h"
#include "string.h"
#include "matrix.h"

//Function Prototypes



enum TYPE_OBJECT{

	TYPE_OBJECT_1

};



int main(int argc, char* args[])
{
	if(AllocConsole()){
		FILE* file;

		freopen_s(&file, "CONOUT$", "wt", stdout);
		freopen_s(&file, "CONOUT$", "wt", stderr);
		freopen_s(&file, "CONOUT$", "wt", stdin);
		

		SetConsoleTitle(L"Engine");

	}

	SDL_Window *pWindow;
	int error = 0;
	bool appIsRunning = true;
	SDL_Surface* pWindowSurface = NULL;
	//SDL_Surface* ppImage[4] = { NULL, NULL, NULL, NULL };

	//Managers
	InputManager* pm = new InputManager();
	ResourceManager* rm = new ResourceManager();
	GameObjectInstance* pInst = new GameObjectInstance();
	Controller* cm = new Controller(pInst);
	FrameRateController* pF = new FrameRateController(30);

	//int ImageID = 0;
	

	// Initialize SDL
	if((error = SDL_Init( SDL_INIT_VIDEO )) < 0 )
	{
		printf("Couldn't initialize SDL, error %i\n", error);
		return 1;
	}

	pWindow = SDL_CreateWindow("SDL2 window",		// window title
		SDL_WINDOWPOS_UNDEFINED,					// initial x position
		SDL_WINDOWPOS_UNDEFINED,					// initial y position
		800,										// width, in pixels
		600,										// height, in pixels
		SDL_WINDOW_SHOWN);

	// Check that the window was successfully made
	if (NULL == pWindow)
	{
		// In the event that the window could not be made...
		printf("Could not create window: %s\n", SDL_GetError());
		return 1;
	}

	//Get the window surface
	pWindowSurface = SDL_GetWindowSurface(pWindow);

	

	

	//load the paricular object
	//LoadObject(pInst,rm);

	//Resource Manager loads the object
	rm->LoadObject(pInst);

	// Load images
	
	

	//GameObjectInstance* pInst = new GameObjectInstance();
	
	
	

	//Load the Images
	/*ppImage[0] = rm->GetSurface("..\\Resources\\Up.bmp");
	ppImage[1] = rm->GetSurface("..\\Resources\\Down.bmp");
	ppImage[2] = rm->GetSurface("..\\Resources\\Left.bmp");
	ppImage[3] = rm->GetSurface("..\\Resources\\Right.bmp");

	for(int i = 0; i < 4; ++i)
		if(NULL == ppImage[i])
		{
			printf("Couldn't load image %i\n", i);
			return 1;
		}*/

	//Apply 1 image on start
	//SDL_BlitSurface(pInst->mpSpriteComponent->mpSprite, NULL, pWindowSurface,NULL);
	//SDL_BlitSurface(ppImage[0], NULL, pWindowSurface,NULL);
			
	//Update the surface
	SDL_UpdateWindowSurface(pWindow);

	// Game loop
	while(true == appIsRunning)
	{
		
		pF->FrameStart();
		SDL_Event e;
		while( SDL_PollEvent( &e ) != 0 )
		{
			//User requests quit
			if( e.type == SDL_QUIT )
			{
				appIsRunning = false;
			}
			
		}

		// Get keyboard state. Note: Not inside message handle loop
		//const Uint8* currentKeyStates = SDL_GetKeyboardState(NULL);

		

			//pm->Update();
		

			// Do the movement using controller
			cm->DoMovement();
		

		
			/*if(pm->IsPressed(SDL_SCANCODE_UP))
			{
				printf("U pressed up");
				SDL_BlitSurface(ppImage[1], NULL, pWindowSurface, NULL);
				SDL_UpdateWindowSurface(pWindow);
			}

			else
				if(pm->IsReleased(SDL_SCANCODE_DOWN))
			{
				printf("U pressed down");
				SDL_BlitSurface(ppImage[1], NULL, pWindowSurface, NULL);
				SDL_UpdateWindowSurface(pWindow);
			}
			else
				if(pm->IsReleased(SDL_SCANCODE_LEFT))
			{
				printf("U pressed left");
				SDL_BlitSurface(ppImage[2], NULL, pWindowSurface, NULL);
				SDL_UpdateWindowSurface(pWindow);
			}
			else
				if(pm->IsReleased(SDL_SCANCODE_RIGHT))
			{
				printf("U pressed right");
				SDL_BlitSurface(ppImage[3], NULL, pWindowSurface, NULL);
				SDL_UpdateWindowSurface(pWindow);
			}
			else
				if(pm->IsReleased(SDL_SCANCODE_ESCAPE))
			{
				appIsRunning = false;
			}
			
			++ImageID;
			if(ImageID >= 4)
				ImageID = 0;*/

			pInst->mpSpriteComponent->DrawAtTransform(pWindowSurface, pInst->mpSpriteComponent->mpSprite, pInst->mpTransformComponent->mPosition.x, pInst->mpTransformComponent->mPosition.y);

			/*SDL_BlitSurface(ppImage[ImageID], NULL, pWindowSurface, NULL);*/

			SDL_UpdateWindowSurface(pWindow);

			pF->FrameEnd();
		
	}

	// Destroy images
	/*SDL_FreeSurface(ppImage[0]);
	SDL_FreeSurface(ppImage[1]);
	SDL_FreeSurface(ppImage[2]);
	SDL_FreeSurface(ppImage[3]);
*/
	delete rm;

	// Close and destroy the window
	SDL_DestroyWindow(pWindow);

	// Quit SDL subsystems
	SDL_Quit();

	return 0;
}

/*

void LoadObject(GameObjectInstance* pInst, ResourceManager* rm)
{
	if (0 != pInst){
		if (0 == pInst->mpSpriteComponent){
			pInst->mpSpriteComponent = (Sprite *)calloc(1, sizeof(Sprite));

		}
		SDL_Surface* mySurface = rm->GetSurface("..\\Resources\\myBmp.bmp");
		pInst->mpSpriteComponent->AddSprite(mySurface);
		pInst->mpSpriteComponent->mpOwner = pInst;
		//pInst->mpSpriteComponent->AddSprite(mySurface);
	}
	if (0 != pInst){
		if (0 == pInst->mpControllerComponent){
			pInst->mpControllerComponent = (Controller *)calloc(1, sizeof(Controller));
		}
		pInst->mpControllerComponent->mpOwner = pInst;
	}
	if (0 != pInst){
		if (0 == pInst->mpTransformComponent){
			pInst->mpTransformComponent = (Transform *)calloc(1, sizeof(Transform));
		}
		pInst->mpTransformComponent->mpOwner = pInst;
		pInst->mpTransformComponent->mPosition.x = 300;
		pInst->mpTransformComponent->mPosition.y = 200;


	}


}
*/
