#ifndef GAMEOBJECTINSTANCE_H
#define GAMEOBJECTINSTANCE_H

#include "Sprite.h"
#include "Transform.h"
#include "Controller.h"

//class Controller;
//class Sprite;
//class Transform;

class GameObjectInstance{

public:
	bool mActive;

	Sprite* mpSpriteComponent;
	Transform* mpTransformComponent;
	Controller* mpControllerComponent;

	

public:
	GameObjectInstance(){
		mpSpriteComponent = NULL;
		mpTransformComponent = NULL;
		mpControllerComponent = NULL;
	}
	~GameObjectInstance(){}
	
};


#endif