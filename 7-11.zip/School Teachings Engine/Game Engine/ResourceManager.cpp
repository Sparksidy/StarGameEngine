#include "ResourceManager.h"
#include "SDL_surface.h"
#include "stdio.h"
#include "stdlib.h"
#include "string.h"

ResourceManager::ResourceManager(){


}
ResourceManager::~ResourceManager(){
	for(auto &i : mSurface)
		SDL_FreeSurface(i.second);

	mSurface.clear();

}
SDL_Surface* ResourceManager:: GetSurface(char* path){

	SDL_Surface* pSurfaces = mSurface[path];

	//Found
	if(pSurfaces!= NULL)
		return pSurfaces;
	//Not Found
	pSurfaces = SDL_LoadBMP(path);

	if(pSurfaces != NULL)
		mSurface[path] = pSurfaces;

	return pSurfaces;

}

void ResourceManager::LoadObject(GameObjectInstance* pInst)
{
	
	if (0 != pInst)
	{
		//Allocating memory for Sprite Component
		if (0 == pInst->mpSpriteComponent)
		{
			pInst->mpSpriteComponent = (Sprite *)calloc(1, sizeof(Sprite));

		}
		pInst->mpSpriteComponent->mpOwner = pInst;

		//Allocating memory for Controller Component
		if (0 == pInst->mpControllerComponent)
		{
				pInst->mpControllerComponent = (Controller *)calloc(1, sizeof(Controller));
			
		}
		pInst->mpControllerComponent->mpOwner = pInst;
		
		//Allocating memory for Transform Component
		if (0 == pInst->mpTransformComponent)
		{
				pInst->mpTransformComponent = (Transform *)calloc(1, sizeof(Transform));
		}
		pInst->mpTransformComponent->mpOwner = pInst;


		//Importing Data from the File
		ImportMapDataFromFile("file.txt", pInst);
			

	}

}

int ResourceManager::ImportMapDataFromFile(char* filename, GameObjectInstance* pInst)
{
	int year;
	int x, y, i;
	char* transform[25];
	char* sprite[25];
	char spriteFileName[35];
	char* formats[] = {
		"%s%",
		"%d%d",
		"%s",
		"%s",
	};

	FILE* fp;
	fp = fopen(filename, "r");

	for (i = 0; i<4; i++)
	{

		while (!feof(fp))
		{

			if (i == 0)//For "Transform"
			{
				fscanf(fp, formats[i], transform);
				printf("%s\n", transform);
			}
			else if (i == 1)//For Transform values
			{
				fscanf(fp, formats[i], &x, &y);
				printf("%d %d\n", x, y);
			}
			else if (i == 2)
			{
				fscanf(fp, formats[i], sprite);
			}
			else if (i == 3)
			{
				fscanf(fp, formats[i], spriteFileName);
			}
			
			break;
		}

	}

	//Assign the transform position
	pInst->mpTransformComponent->mPosition.x = x;
	pInst->mpTransformComponent->mPosition.y = y;

	
	//Get the Sprite
	SDL_Surface* mySurface = this->GetSurface(spriteFileName);
	if (mySurface != NULL)
	{
		pInst->mpSpriteComponent->mpSprite = mySurface;	
	}
	
	//Close the file used
	fclose(fp);


	return 1;

}

