#ifndef RESOURCEMANAGER_H
#define RESOURCEMANAGER_H

#include <string>
#include <unordered_map>
#include "GameObjectInstance.h"

struct SDL_Surface;

class ResourceManager{

public:
	ResourceManager();
	~ResourceManager();

	SDL_Surface *GetSurface(char* path);

	/*
	Loads the Game object instance with a specific set of components
	*/
	void LoadObject(GameObjectInstance* pInst);

	/*
		Imports the data from the File and assigns it to the GameObjectInstance  
		Transform
		x y
		Sprite
		Sprite Location

	*/

	int ImportMapDataFromFile(char* filename, GameObjectInstance* pInst);


public:
	std::unordered_map<std::string, SDL_Surface*>mSurface;


};



#endif