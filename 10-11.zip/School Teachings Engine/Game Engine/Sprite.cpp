#include "Sprite.h"



Sprite::~Sprite(){


}

void Sprite::AddSprite(SDL_Surface* surface){
	mSurface = surface;

}

void Sprite:: DrawAtTransform(SDL_Surface* Surf_Dest, SDL_Surface* Surf_Src, int X, int Y){
	

	if (Surf_Dest == NULL || Surf_Src == NULL){
		return;
	}

	SDL_Rect Dest_R;
	Dest_R.x = X;
	Dest_R.y = Y;

	SDL_BlitSurface(Surf_Src, NULL, Surf_Dest, &Dest_R);

}

void Sprite::Serialize(FILE** fpp)
{
	char spriteFileName[256];
	memset(spriteFileName, 0, 256 * sizeof(char));
	//Reading file location and storing them in the component
	fscanf(*fpp, "%s",spriteFileName);
	LoadSprite(spriteFileName);
	
}

void Sprite::LoadSprite(char* path)
{
	
	ResourceManager* rm = new ResourceManager();
	mSurface = rm->GetSurface(path);
	


}

			



 

