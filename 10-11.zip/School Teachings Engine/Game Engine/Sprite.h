#ifndef SPRITE_H
#define SPRITE_H
#include <stdio.h>
#include <SDL.h>
#include "Component.h"
#include <string>
#include "GameObjectInstance.h"
#include "ResourceManager.h"


class GameObjectInstance;

class Sprite: public Component{

public:
	Sprite(){
		mSurface = NULL;
	}
	
	~Sprite();

	void AddSprite(SDL_Surface* surface);
	
	void DrawAtTransform(SDL_Surface* Surf_Dest, SDL_Surface* Surf_Src, int X, int Y);
	
	 void Update(){}

	 void Serialize(FILE** fpp);

	 void LoadSprite(char* path);
	

public:
	SDL_Surface* mSurface;

	

};



#endif